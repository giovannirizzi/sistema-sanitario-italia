Sass is more than a technology; Sass is driven by the community of individuals
that power its development and use every day. As a community, we want to embrace
the very differences that have made our collaboration so powerful, and work
together to provide the best environment for learning, growing, and sharing of
ideas. It is imperative that we keep Sass a fun, welcoming, challenging, and
fair place to play.

[The full community guidelines can be found on the Sass website.][link]

[link]: https://sass-lang.com/community-guidelines
